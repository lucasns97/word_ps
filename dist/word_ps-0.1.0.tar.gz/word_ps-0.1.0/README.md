# WORD PS

## A module for word similarity evaluation

### Author: Lucas Nunes Sequeira